function [X, gamma_chosen,  CC_MDS_size_stat] = CC_MDS(PPI_file, gamma, method, result_file)
% CC_MDS is the corresponding matlab function of the proposed model. It reads data (PPI network) from  text
% file (PPI_file) using function: PPI_read,  and determines driver proteins using the model
% described in the paper. It also writes the determined driver proteins
% into file 'result_file' where each line is a predicted driver protein. 


% Inputs:
%   PPI_file: the input file name of the PPI network, where each line
%   contains two proteins defining the interaction between them.
%   Example: ABI1	ABL1	

%   gamma��the weight parameter. If it is a vector, a gird search method
%   will be used to determine the optimal value; if it is a real number,
%   the model uses it to set the weights. The default value is 0.05.

%   method: the optimization methods ('lp_solve' or 'intlinprog') that will be used to solve the binary
%   integer-programming problem. The default value is 'lp_solve'.

%   output_file_name: the file into which the predicted driver proteins will be written. Each line is a 
%   a predicted driver protein.
%   Example: ABL1

% Outputs:
%   X: the binary vector that indicates whether a protein is a member of
%   detetermined CC-MDS. 

%   gamma_chosen: the value of gamma that is chosen to set the weights

%   CC_MDS_size_stat: the number of determined driver proteins with respect
%   to different values of gamma



%PPI data read
Data_set = PPI_read(PPI_file);
A = Data_set.PPI;

fprintf('Computing...')
fprintf('\n')

%compute the number of proteins
n = size(A,1);
A = A-diag(diag(A));
%compute degree of proteins
Degree = sum(A,2);
%compute betweenness of proteins
Betweenness = betweenness_centrality(A);
Betweenness = Betweenness/((n-1)*(n-2));
Betweenness (Betweenness==0) = eps;

% add self-interactions
A = A-diag(diag(A)) +eye(size(A));

CC_MDS_size_stat = zeros(length(gamma),1);
need_node_min = inf;

switch method
    % choose optimization method 'lp_solve'
    case 'lp_solve'
        for i = 1:length(gamma)
            % set weights according to Equation (3)
            Weights = (Degree.*Betweenness).^(-gamma(i));
            % solve CC-MDS model (Equation (2)) using library 'lp_solve'
            [~,temp_X,~,~] = lp_solve(-Weights ,A, ones(n,1),ones(n,1),zeros(n,1),ones(n,1),1:n);
            CC_MDS_size_stat(i) = sum(temp_X);
            if sum(temp_X) <= need_node_min
                X=  temp_X;
                gamma_chosen  = gamma(i);
                need_node_min = sum(temp_X);
            end
        end
        
    case 'intlinprog'
        for i = 1:length(gamma)
            % set weights according to Equation (3)
            Weights = (Degree.*Betweenness).^(-gamma(i));
            % solve CC-MDS model (Equation (2)) using function 'intlinprog'
            temp_X = intlinprog(Weights, 1:n, -A, -ones(n,1), [], [], zeros(n,1), ones(n,1));
            CC_MDS_size_stat(i) = sum(temp_X);
            if sum(temp_X) <= need_node_min
                X =  temp_X;
                gamma_chosen  = gamma(i);
                need_node_min = sum(temp_X);
            end
        end
end

% Write the result of predicted driver proteins into file 'result_file'.
result_print(result_file, Data_set.Protein,  X)




function Data_set = PPI_read(PPI_profie) %#ok<*DEFNU>
fprintf('Reading data...')
fprintf('\n')
fid_ppi=fopen(PPI_profie);
temp_PPI=textscan(fid_ppi,'%s%s%*[^\n]','delimiter','\t');
fclose(fid_ppi);

Data_set.Protein = union(temp_PPI{1},temp_PPI{2});
[~,Locb_1] = ismember(temp_PPI{1}, Data_set.Protein);
[~,Locb_2] = ismember(temp_PPI{2}, Data_set.Protein);
Data_set.PPI = sparse(Locb_1,Locb_2,1,length(Data_set.Protein),length(Data_set.Protein));
Data_set.PPI = Data_set.PPI + Data_set.PPI';

function result_print(result_file, Proteins,  X)
Drivers_proteins = Proteins(logical(X));
fid = fopen(result_file,'w');
for i = 1:length(Drivers_proteins)
    fprintf(fid, '%s',Drivers_proteins{i});
    fprintf(fid, '\n');
end
fclose(fid);
fprintf(['The predicted driver proteins have been written into file ', result_file])
fprintf('\n')

