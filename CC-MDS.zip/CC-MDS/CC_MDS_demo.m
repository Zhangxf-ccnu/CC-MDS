%%
% CC-MDS model; select gamma using grid search; optimization method "lp_solve"
clear 
gamma = 0:0.05:1;
% HumanCombinedHQ 
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanCombinedHQ_ConnComp.txt', gamma, 'lp_solve', 'HumanCombinedHQ_CC_MDS_lp_solve.txt');

%%
clear 
gamma = 0:0.05:1;
% HumanBinaryHQ
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanBinaryHQ_ConnComp.txt', gamma, 'lp_solve', 'HumanBinaryHQ_CC_MDS_lp_solve.txt');

%%
clear 
gamma = 0:0.05:1;
% HumanComplex
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanComplexHQ_ConnComp.txt', gamma, 'lp_solve', 'HumanComplexHQ_CC_MDS_lp_solve.txt');

%%
% CC-MDS model; select gamma using grid search; optimization method "intlinprog"
clear 
gamma = 0:0.05:1;
% HumanCombinedHQ 
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanCombinedHQ_ConnComp.txt', gamma, 'intlinprog', 'HumanCombinedHQ_CC_MDS_intlinprog.txt');
%%
clear 
gamma = 0:0.05:1;
% HumanBinaryHQ
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanBinaryHQ_ConnComp.txt', gamma, 'intlinprog', 'HumanBinaryHQ_CC_MDS_intlinprog.txt');
%%
clear 
gamma = 0:0.05:1;
% HumanComplex
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanComplexHQ_ConnComp.txt', gamma, 'intlinprog', 'HumanComplexHQ_CC_MDS_intlinprog.txt');

%%
% MDS model;  gamma = 0; optimization method "lp_solve"
clear 
gamma = 0;
% HumanCombinedHQ 
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanCombinedHQ_ConnComp.txt', gamma, 'lp_solve', 'HumanCombinedHQ_MDS_lp_solve.txt');
%%
clear 
gamma = 0;
% HumanBinaryHQ
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanBinaryHQ_ConnComp.txt', gamma, 'lp_solve', 'HumanBinaryHQ_MDS_lp_solve.txt');
%%
clear 
gamma = 0;
% HumanComplex
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanComplexHQ_ConnComp.txt', gamma, 'lp_solve', 'HumanComplexHQ_MDS_lp_solve.txt');

%%
% MDS model;  gamma = 0; optimization method  "intlinprog"
clear 
gamma = 0;
% HumanCombinedHQ 
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanCombinedHQ_ConnComp.txt', gamma, 'intlinprog', 'HumanCombinedHQ_MDS_intlinprog.txt');
%%
clear 
gamma = 0;
% HumanBinaryHQ
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanBinaryHQ_ConnComp.txt', gamma, 'intlinprog', 'HumanBinaryHQ_MDS_intlinprog.txt');
%%
clear 
gamma = 0;
% HumanComplex
[X, gamma_choosed,  CC_MDS_size_stat] = CC_MDS('.\data\HumanComplexHQ_ConnComp.txt', gamma, 'intlinprog', 'HumanComplexHQ_MDS_intlinprog.txt');
